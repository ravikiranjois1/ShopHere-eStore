export const rest_endpoint = 'https://iowk7vjuy2.execute-api.us-east-1.amazonaws.com/dev/';
export const accessKeyId = 'AKIAJHTU3RNSAWF2WTDA';
export const secretAccessKey = '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';
